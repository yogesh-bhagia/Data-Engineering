object ScalaDemo {
  def main(args: Array[String]): Unit = {
    println("Hello world ! My first scala program.")
    var a = 3
    var b = 5
    var c = a +b
    println("a+b = " + c)
  }

}
